self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a2f94f5d94f7d3b648c63326a40b151b",
    "url": "/test-login-form/index.html"
  },
  {
    "revision": "e3f90cf13d93cec326b0",
    "url": "/test-login-form/static/css/2.775edd8e.chunk.css"
  },
  {
    "revision": "c9a07cf7b7d6e28734a7",
    "url": "/test-login-form/static/css/4.1c41e103.chunk.css"
  },
  {
    "revision": "72d7e2135c2a014eae64",
    "url": "/test-login-form/static/css/main.0d896b71.chunk.css"
  },
  {
    "revision": "e3f90cf13d93cec326b0",
    "url": "/test-login-form/static/js/2.484e4b80.chunk.js"
  },
  {
    "revision": "97b083be2e05f6c86d4aab0d88d43a94",
    "url": "/test-login-form/static/js/2.484e4b80.chunk.js.LICENSE.txt"
  },
  {
    "revision": "63520a8dc30ad11e3e07",
    "url": "/test-login-form/static/js/3.1c943dc4.chunk.js"
  },
  {
    "revision": "c9a07cf7b7d6e28734a7",
    "url": "/test-login-form/static/js/4.8a583d39.chunk.js"
  },
  {
    "revision": "72d7e2135c2a014eae64",
    "url": "/test-login-form/static/js/main.a1798966.chunk.js"
  },
  {
    "revision": "f25c06f39e8906d10268",
    "url": "/test-login-form/static/js/runtime-main.9625ecb3.js"
  }
]);